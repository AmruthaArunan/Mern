const name = "sometthing";

console.log(name);

const name2 = "some";

console.log(name2);

const name3 = "some";

console.log(name2);