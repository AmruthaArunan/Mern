const name = "sometthing";

console.log(name);

const data = "some";

console.log(data);