const name = 'sherlock';

console.log(name);